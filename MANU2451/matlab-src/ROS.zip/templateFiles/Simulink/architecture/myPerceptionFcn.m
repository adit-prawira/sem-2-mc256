function perceptionOutput = myPerceptionFcn(perceptionInput,param)
% Placeholder perception algorithm
% Copyright 2017 The MathWorks, Inc.

    perceptionOutput = perceptionInput / param; 

end



