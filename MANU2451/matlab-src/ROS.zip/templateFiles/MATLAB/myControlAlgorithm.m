function ctrlOutput = myControlAlgorithm(ctrlInput,params)
% Placeholder control algorithm
% Copyright 2017 The MathWorks, Inc.

    ctrlOutput = ctrlInput * params.gain;

end

