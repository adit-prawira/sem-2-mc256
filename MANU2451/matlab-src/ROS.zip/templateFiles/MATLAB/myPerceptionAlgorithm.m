function perceptionOutput = myPerceptionAlgorithm(recvData,param)
% Placeholder perception algorithm
% Copyright 2017 The MathWorks, Inc.

    perceptionOutput = recvData / param; 

end

