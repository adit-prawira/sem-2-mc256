%% Modify the IP addresses of your ROS enabled robots/simulators here
% Copyright 2017 The MathWorks, Inc.

% Gazebo IP address
gazeboIp = '192.168.119.133';

% Turtlebot IP address
turtlebotIp = '172.31.28.38';