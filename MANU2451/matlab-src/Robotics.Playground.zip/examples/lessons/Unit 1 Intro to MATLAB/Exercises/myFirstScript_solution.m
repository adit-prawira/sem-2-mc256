clear
clc

result1=2+3;
result2=4+5;
result3=result1 + result2