clear
clc

a=12;
b=17;
c=sqrt(a^2 + b^2)