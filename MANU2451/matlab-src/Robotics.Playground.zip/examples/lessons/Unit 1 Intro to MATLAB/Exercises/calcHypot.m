function c = calcHypot(a,b)
%calcHypoth Solution

% This function calculates the hypothenuse given the length
% of two for the sides of a right triangle
c=sqrt(a^2+b^2);
    
end

