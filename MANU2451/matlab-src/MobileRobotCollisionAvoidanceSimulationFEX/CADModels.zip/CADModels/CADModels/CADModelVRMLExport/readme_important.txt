The features in SinglePioneerWMotorNOPlates_FeaturesSuppressed.SLDPRT are suppressed in order to reduce the file size.

To restore it, select features from "Combine1" to "Body-Delete4", right-click, and choosle "Unsuppress".